/*
  Add your products here. Duplicate an item to add another one.
  image: use a photo filename (example: "images/blue-shirt.jpg") or leave it empty.
  category must be: Tops, Pants, Outerwear, or Other.
  Set sold: true when an item is no longer available.
*/
const PRODUCTS = [
  { id: 1, name: "Vintage top", category: "Tops", size: "M", condition: "Très bon état", price: 25, image: "", sold: false },
  { id: 2, name: "Classic denim", category: "Pants", size: "38", condition: "Bon état", price: 35, image: "", sold: false },
  { id: 3, name: "Everyday jacket", category: "Outerwear", size: "S-M", condition: "Très bon état", price: 45, image: "", sold: false }
];
