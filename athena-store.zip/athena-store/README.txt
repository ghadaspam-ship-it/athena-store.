ATHENA — starter online store

WHAT THIS WEBSITE DOES
- Responsive storefront with product categories.
- Product cards with size, condition, price and sold status.
- Shopping cart.
- WhatsApp order request sent to +216 51 979 797.
- Customers can request local delivery in Ben Arous or postal shipping; you confirm availability, fees and payment details directly.

IMPORTANT
This is a free static website starter. It does not collect card details or take online payments. Orders are requests sent to WhatsApp, and you confirm each order manually.

HOW TO ADD YOUR PRODUCTS
1. Open products.js in a text editor.
2. Replace the sample products with your real items.
3. Each product needs: id, name, category, size, condition, price, image, sold.
4. Put product photos in a folder named images and set image to e.g. "images/black-jacket.jpg".
5. Set sold: true when an item is sold.

HOW TO PUBLISH FOR FREE WITH GITHUB PAGES
1. Create/sign in to a GitHub account.
2. Create a new public repository named athena-store.
3. Upload index.html, style.css, script.js, products.js and your images folder.
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. GitHub will provide a public website address after deployment.

Before publishing, check the phone number, product details, delivery area and payment wording. You can change the number in script.js (PHONE constant) and in index.html (WhatsApp footer link).
