const PHONE = '21651979797';
let cart = [];
let activeFilter = 'All';
const grid = document.getElementById('productGrid');
const money = n => `${Number(n).toFixed(2).replace(/\.00$/, '')} DT`;

function renderProducts(){
  const items = PRODUCTS.filter(p => activeFilter === 'All' || p.category === activeFilter);
  grid.innerHTML = items.map(p => `
    <article class="product-card">
      <div class="product-image">
        ${p.image ? `<img src="${p.image}" alt="${p.name}" loading="lazy">` : `<div class="image-placeholder">ATHENA FIND Nº${String(p.id).padStart(2,'0')}</div>`}
        ${p.sold ? '<span class="sold-tag">SOLD</span>' : ''}
      </div>
      <div class="product-info"><div><h3>${p.name}</h3><p>Size ${p.size} · ${p.condition}</p></div><div class="price">${money(p.price)}</div></div>
      <button class="add-button" data-id="${p.id}" ${p.sold ? 'disabled' : ''}>${p.sold ? 'INDISPONIBLE' : 'AJOUTER AU PANIER +'}</button>
    </article>`).join('');
}
function renderCart(){
  const box = document.getElementById('cartItems');
  document.getElementById('cartCount').textContent = cart.reduce((s,x)=>s+x.qty,0);
  document.getElementById('cartTotal').textContent = money(cart.reduce((s,x)=>s+x.price*x.qty,0));
  box.innerHTML = cart.length ? cart.map(x=>`<div class="cart-row"><div><strong>${x.name}</strong><small>Size ${x.size} · ${money(x.price)} × ${x.qty}</small></div><button class="remove-item" data-remove="${x.id}">RETIRER</button></div>`).join('') : '<p class="empty-cart">Ton panier est encore vide.</p>';
}
function openCart(){document.body.classList.add('cart-open');document.getElementById('cartDrawer').setAttribute('aria-hidden','false')}
function closeCart(){document.body.classList.remove('cart-open');document.getElementById('cartDrawer').setAttribute('aria-hidden','true')}

grid.addEventListener('click', e=>{
  const btn=e.target.closest('[data-id]'); if(!btn)return;
  const p=PRODUCTS.find(x=>x.id===Number(btn.dataset.id)); if(!p||p.sold)return;
  const existing=cart.find(x=>x.id===p.id); if(existing) existing.qty++; else cart.push({...p,qty:1});
  renderCart(); btn.textContent='AJOUTÉ ✓'; setTimeout(()=>{if(btn.isConnected)btn.textContent='AJOUTER AU PANIER +'},900);
});
document.getElementById('cartItems').addEventListener('click',e=>{const b=e.target.closest('[data-remove]');if(!b)return;cart=cart.filter(x=>x.id!==Number(b.dataset.remove));renderCart()});
document.getElementById('filters').addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;activeFilter=b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));renderProducts()});
document.getElementById('openCart').addEventListener('click',openCart);
document.getElementById('closeCart').addEventListener('click',closeCart);
document.getElementById('cartBackdrop').addEventListener('click',closeCart);
document.getElementById('checkout').addEventListener('click',()=>{
  if(!cart.length){alert('Ton panier est vide pour le moment.');return;}
  const lines=cart.map(x=>`• ${x.name} — taille ${x.size} — ${x.qty} × ${money(x.price)}`).join('\n');
  const total=money(cart.reduce((s,x)=>s+x.price*x.qty,0));
  const message=`Bonjour ATHENA ! Je souhaite commander :\n\n${lines}\n\nTotal des articles : ${total}\n\nMon nom :\nMa zone / adresse (Ben Arous) :\nMode souhaité (livraison locale / envoi postal) :\n\nPouvez-vous confirmer la disponibilité, les frais et les modalités de paiement ?`;
  window.open(`https://wa.me/${PHONE}?text=${encodeURIComponent(message)}`,'_blank','noopener');
});
document.getElementById('year').textContent=new Date().getFullYear();
renderProducts();renderCart();
